import os
import sys

sys.path.insert(0, "/home/sanaaob/sanaonlineshop")

os.environ.setdefault(
    "DJANGO_SETTINGS_MODULE",
    "sana.settings"
)

from django.core.wsgi import get_wsgi_application

application = get_wsgi_application()